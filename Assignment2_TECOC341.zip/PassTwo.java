import java.io.*;
import java.util.*;

class Symbol {
	String sname;
	int addr;
	int length;

	Symbol(String sname, int addr,int length) {
		this.sname = sname;
		this.addr = addr;
		this.length=length;
	}
}

class Literal {
	String lname;
	int laddr;
	Literal(String lname,int laddr)
	{
		this.lname=lname;
		this.laddr=laddr;
	}
}
public class PassTwo {
	HashMap<Integer, String> POT = new HashMap<Integer , String>();
	
	int[] ptab = new int[10];
	Symbol[] st = new Symbol[20];
	Literal[] lt = new Literal[20];
	int sIndex, lIndex, lc, pIndex,pcount;
	
	PassTwo() {
		sIndex = 0;
		lIndex = 0;
		pIndex = 0;
		lc = 0;
		ptab[0] = 0;
		pcount=0;
		
		POT.put(1,"START");
		POT.put(2,"END");
		POT.put(3,"EQU");
		POT.put(4,"LTORG");
		POT.put(5,"ORIGIN");
		}
	void initTables() throws Exception
	{
		File fsym=new File("symboltable.txt");
		File flit=new File("literaltable.txt");
		File fptab=new File("pooltable.txt");
		BufferedReader br=new BufferedReader(new FileReader(fsym));
		br.readLine();
		
		String st1="";
		
		while((st1=br.readLine())!=null)
		{
			String token[]=st1.split("\t");
			st[sIndex]=new Symbol(token[0],Integer.parseInt(token[1]),Integer.parseInt(token[2]));
			sIndex++;
		}
		br.close();
		
		br=new BufferedReader(new FileReader(flit));
		br.readLine();
		
		while((st1=br.readLine())!=null)
		{
			String token[]=st1.split("\t");
			lt[lIndex]=new Literal(token[0],Integer.parseInt(token[1]));
			lIndex++;
		}
		br.close();
		
		br=new BufferedReader(new FileReader(fptab));
		br.readLine();
		
		while((st1=br.readLine())!=null)
		{
			String token[]=st1.split("\t");
			ptab[pIndex]=Integer.parseInt(token[0]);
			pIndex++;
		}
		br.close();
		
		System.out.println("******Symbol Table******\n-------------------------------------------------------------\n");
		System.out.println("Symbol\tAddress\tLength\n");
		for (int i = 0; i < sIndex; i++)
			System.out.println(st[i].sname + "\t" + st[i].addr + "\t" + st[i].length);
		

		System.out.println("******Literal Table******\n-------------------------------------------------------------\n");
		System.out.println("Literal\tAddress");
		for (int i = 0; i < lIndex; i++)
			System.out.println(lt[i].lname + "\t" + lt[i].laddr);

		System.out.println("******Pool Table******\n-------------------------------------------------------------\n");
		System.out.println("Pool Index");
		for (int i = 0; i < pIndex; i++)
			System.out.println(ptab[i] + "\n");
		
	}
	void passTwo(BufferedReader br)throws Exception
	{
		String st1="";
		int k;
		FileWriter fw=new FileWriter("output.txt");
		
		System.out.println("\n******Machine Code******");
		while((st1=br.readLine())!=null)
		{
			String token[]=st1.split(" ");
			if(token[0].equals("AD"))
			{
				String pot_content=POT.get(Integer.parseInt(token[1]));
				if(pot_content.equals("START")){
					if(token.length==4)
						lc=Integer.parseInt(token[3]);
					else
						lc=0;
				}
				else if(pot_content.equals("END"))
				{
					for(int i=ptab[pcount];i<lIndex;i++)
					{
						System.out.println(lc+"] 00 "+lt[i].lname);
						fw.write(lc+"] 00 "+lt[i].lname+"\n");
						lc++;
					}
					pcount++;
				}
				else if(pot_content.equals("LTORG"))
				{
					for(int i=ptab[pcount];i<ptab[pcount+1];i++)
					{
						System.out.println(lc+"] 00 "+lt[i].lname);
						fw.write(lc+"] 00 "+lt[i].lname+"\n");
						lc++;
					}
					pcount++;
				}	
			}
			else if(token[0].equals("DL"))
			{
				int c=Integer.parseInt(token[1]);
				if(c==2)
				{
					System.out.println(lc+"] 00 "+token[4]);
					fw.write(lc+"] 00 "+token[4]+"\n");
					lc+=1;
				}
				else
				{
					System.out.println(lc+"]");
					fw.write(lc+"]"+"\n");
					lc+=Integer.parseInt(token[4]);
				}
			}
			else
			{
				if(token[3].equals("S"))
				{
					int symaddr=st[Integer.parseInt(token[4])].addr;
					System.out.println(lc+"] 0"+token[1]+" "+token[2]+" "+symaddr);
					fw.write(lc+"] 0"+token[1]+" "+token[2]+" "+symaddr+"\n");
					lc+=1;
				}
				else
				{
					int litaddr=lt[Integer.parseInt(token[4])].laddr;
					System.out.println(lc+"] 0"+token[1]+" "+token[2]+" "+litaddr);
					fw.write(lc+"] 0"+token[1]+" "+token[2]+" "+litaddr+"\n");
					lc+=1;
				}
			}
		}
		fw.close();
		
	}

	public static void main(String[] args) throws Exception{
		File f=new File("Pass1_output.txt");
		BufferedReader br=new BufferedReader(new FileReader(f));
		
		PassTwo o=new PassTwo();
		o.initTables();
		o.passTwo(br);
		// TODO Auto-generated method stub

	}

}
